<?php
/**
 * /* Template Name: home 
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Math_Calculator
 */

get_header();
?>
<div id="calculator">
    <div id="input-wrap">
        <div id="tmp"></div>
        <div id="input"></div>
    </div>
    <div id="button-wrap">
         <button id="mr">MR</button>
        <button id="m_add">M+</button>
        <button id="m_sub">M-</button>
         <button id="mc">MC</button>
        <button id="all-clear">AC</button>
        <button id="clear">C</button>
        <button id="sign">+/-</button>
        <button class="amt divide">/</button>

        <button class="number">7</button>
        <button class="number">8</button>
        <button class="number">9</button>
        <button class="amt times">*</button>

        <button class="number">4</button>
        <button class="number">5</button>
        <button class="number">6</button>
        <button class="amt minus">-</button>

        <button class="number">1</button>
        <button class="number">2</button>
        <button class="number">3</button>
        <button class="amt plus">+</button>

        <button class="number num-0">0</button>
        <button id="dot">.</button>
        <button id="result">=</button>
    </div>
</div>

<?php

get_footer();